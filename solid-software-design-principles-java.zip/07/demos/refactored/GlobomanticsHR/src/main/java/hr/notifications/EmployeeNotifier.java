package hr.notifications;

import hr.personnel.Employee;

public interface EmployeeNotifier {
    void notify(Employee employee);
}
