package hr.documents;

public interface ExportableText {
    String toTxt();
}
