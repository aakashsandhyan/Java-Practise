package hr.documents;

public interface ExportableJson {
    String toJson();
}
